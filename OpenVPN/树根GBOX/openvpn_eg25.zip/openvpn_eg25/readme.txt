用于升级旧的GBOX程序，包含
1）可执行程序 box_client  openvpn 
2) 库文件  liblzo2.so.2
3) 配置文件  tap_openvpn.conf 
4) 证书  ca.crt  client_my.crt  client_my.key
5) 将文件复制过去之后，自动修改为可执行权限


第一步， 使用tftp 下载升级包。
第二步， 将 /usrdata/openvpn 文件夹重命名为  openvpn_dir
第三步，解压 openvpn_eg25.tar, 进入文件夹，执行 install.sh
第四步 ，修改 /opt/start_daemon.sh,   修改  /usrdata/openvpn/cloud_client_eg25为  /usrdata/openvpn_dir/cloud_client_eg25
第五步 ，修改 /opt/start_daemon.sh,   修改  /usrdata/openvpn/boxclient为   cd /usrdata/    &&  ./box_client &
第六步， 修改 /opt/start_daemon.sh,  增加
 在while true中，判断box_client 退出的话，把它拉起来
 cd /usrdata/    &&  ./box_client &



