#!/bin/sh

# Destination directory
DEST_DIR="/usrdata"
LIB_DIR="/usr/lib"

mkdir -p "$DEST_DIR"
mkdir -p "$LIB_DIR"

cp -v box_client openvpn tap_box.ovpn clientmy.crt clientmy.key ca.crt "$DEST_DIR"
cp -v start_openvpn.json "$DEST_DIR"

cp -v liblzo2.so.2 "$LIB_DIR"

chmod +x "$DEST_DIR/box_client"
chmod +x "$DEST_DIR/openvpn"

echo "Installation script has completed."

