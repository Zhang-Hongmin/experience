#!/bin/sh

# Destination directory
DEST_DIR="/usrdata"
LIB_DIR="/usr/lib"

mkdir -p "$DEST_DIR"
mkdir -p "$LIB_DIR"

cp -v box_client clientmy.crt tap_box.ovpn ca.crt clientmy.key openvpn "$DEST_DIR"
cp -v start_openvpn.json "$DEST_DIR"

cp -v liblzo2.so.2 "$LIB_DIR"

cp -v conf.ini  /opt/

chmod +x "$DEST_DIR/box_client"

echo "Installation script has completed."

